#include "country.h"

Country::Country(QString name,QString flag,QString prefix):country_name(name),flag_number(flag),prefix_number(prefix)
{

}

QString Country::get_name()
{
    return country_name;
}

QString Country::get_flag_number()
{
    return flag_number;
}

QString Country::get_prefix_number()
{
    return prefix_number;
}


